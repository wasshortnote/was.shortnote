STUDY NOTE — STARTER WEBSITE
============================

ไฟล์ในชุดนี้
- index.html   โครงสร้างหน้าเว็บไซต์
- styles.css   สี ฟอนต์ และการจัดวาง
- script.js    ข้อมูลสินค้า ปุ่ม Details และข้อมูล LINE

วิธีแก้ข้อมูล
1. เปิดไฟล์ script.js ด้วยโปรแกรมแก้ไขข้อความ
2. แก้รายการใน PRODUCTS:
   - name = ชื่อวิชา
   - subtitle = คำอธิบายสั้น ๆ
   - midterm = ราคากลางภาค (ใส่ตัวเลข เช่น 89)
   - final = ราคาปลายภาค
   - bundle = ราคาแพ็กคู่ (เว้น "" ถ้าไม่มี)
   - description = รายละเอียดสินค้า
   - previewImages = ชื่อไฟล์ภาพตัวอย่าง เช่น ["previews/sample-1.jpg"]
3. ใส่ LINE ID ใน STORE.lineId
4. ใส่ลิงก์ LINE ใน STORE.lineUrl
5. ใส่ไฟล์ QR Code ไว้ในโฟลเดอร์ images แล้วใส่ path ใน STORE.qrImage เช่น "images/line-qr.png"

วิธีเพิ่มรูปภาพตัวอย่าง
- สร้างโฟลเดอร์ชื่อ previews
- ใส่รูป JPG หรือ PNG ลงไป
- ระบุ path ของภาพใน previewImages ของสินค้าที่ต้องการ

วิธีเพิ่ม QR Code
- สร้างโฟลเดอร์ชื่อ images
- ใส่รูป QR Code ของร้าน
- แก้ STORE.qrImage ใน script.js

เผยแพร่ด้วย Cloudflare Pages (Direct Upload)
1. สมัคร/เข้าสู่ระบบ https://dash.cloudflare.com/
2. เปิด Workers & Pages
3. เลือก Create application > Pages > Direct Upload / Upload assets
4. ตั้งชื่อโปรเจกต์ เช่น study-note-store
5. อัปโหลด ZIP นี้ หรือแตก ZIP แล้วอัปโหลดโฟลเดอร์ที่มี index.html อยู่ระดับบนสุด
6. กด Deploy
7. เว็บไซต์จะได้ URL รูปแบบ https://ชื่อโปรเจกต์.pages.dev

หมายเหตุ
- ชุดนี้เป็นเว็บไซต์หน้าร้าน/แคตตาล็อก ไม่ได้ประมวลผลบัตรเครดิตหรือรับชำระเงินในเว็บ
- ลูกค้าติดต่อและชำระเงินผ่านช่องทางที่เจ้าของร้านแจ้งเอง
- ยังไม่มีชื่อวิชา ราคา LINE ID หรือ QR Code จริง จึงใส่ช่องว่าง/ตัวอย่างไว้ก่อน
- ถ้าจะใช้ขายจริง ควรใส่เฉพาะเอกสารที่มีสิทธิ์เผยแพร่ และตรวจข้อมูล/ราคา/ลิงก์ก่อนเปิดเว็บ
