/*
  STUDY NOTE — แก้ข้อมูลร้านตรงนี้ได้
  1) เปลี่ยนชื่อวิชาและราคาใน PRODUCTS
  2) ใส่ LINE ID ใน STORE.lineId
  3) ใส่ลิงก์ LINE ใน STORE.lineUrl
  4) ใส่ชื่อไฟล์ QR ใน STORE.qrImage เช่น "images/line-qr.png"
  5) ใส่ไฟล์ภาพตัวอย่าง PDF ใน previewImages เช่น ["previews/econ-1.jpg"]
*/
const STORE = {
  lineId: "",
  lineUrl: "",
  qrImage: ""
};

const PRODUCTS = [
  {
    id: "subject-01",
    code: "SUBJECT 01",
    name: "ชื่อรายวิชาที่ 1",
    subtitle: "คำอธิบายสั้น ๆ ของชีทสรุป",
    midterm: "",
    final: "",
    bundle: "",
    description: "เพิ่มรายละเอียดเนื้อหา ขอบเขตบทเรียน และจุดเด่นของชีทสรุปในส่วนนี้",
    previewImages: []
  },
  {
    id: "subject-02",
    code: "SUBJECT 02",
    name: "ชื่อรายวิชาที่ 2",
    subtitle: "คำอธิบายสั้น ๆ ของชีทสรุป",
    midterm: "",
    final: "",
    bundle: "",
    description: "เพิ่มรายละเอียดเนื้อหา ขอบเขตบทเรียน และจุดเด่นของชีทสรุปในส่วนนี้",
    previewImages: []
  },
  {
    id: "subject-03",
    code: "SUBJECT 03",
    name: "ชื่อรายวิชาที่ 3",
    subtitle: "คำอธิบายสั้น ๆ ของชีทสรุป",
    midterm: "",
    final: "",
    bundle: "",
    description: "เพิ่มรายละเอียดเนื้อหา ขอบเขตบทเรียน และจุดเด่นของชีทสรุปในส่วนนี้",
    previewImages: []
  }
];

const productList = document.getElementById("product-list");
const dialog = document.getElementById("detail-dialog");
const dialogContent = document.getElementById("dialog-content");

function formatPrice(value) {
  if (value === "" || value === null || value === undefined) return "ยังไม่ระบุ";
  const number = Number(value);
  return Number.isFinite(number) ? `฿${number.toLocaleString("th-TH")}` : String(value);
}

function renderProducts() {
  document.getElementById("item-count").textContent = `${PRODUCTS.length} ITEMS`;
  productList.innerHTML = "";
  PRODUCTS.forEach((product) => {
    const row = document.createElement("article");
    row.className = "product-row";
    row.innerHTML = `
      <div class="subject-cell">
        <span class="subject-name"></span>
        <span class="subject-meta"></span>
      </div>
      <div class="price-cell"><span class="price-label">MIDTERM</span><span class="midterm-price"></span></div>
      <div class="price-cell"><span class="price-label">FINAL</span><span class="final-price"></span></div>
      <button class="details-button" type="button">DETAILS ↗</button>
    `;
    row.querySelector(".subject-name").textContent = product.name;
    row.querySelector(".subject-meta").textContent = product.subtitle || product.code;
    row.querySelector(".midterm-price").textContent = formatPrice(product.midterm);
    row.querySelector(".final-price").textContent = formatPrice(product.final);
    row.querySelector(".details-button").addEventListener("click", () => openDetails(product));
    productList.appendChild(row);
  });
}

function openDetails(product) {
  const preview = product.previewImages && product.previewImages.length
    ? product.previewImages.map(src => `<img class="preview-image" src="${escapeHtml(src)}" alt="ตัวอย่างชีท" loading="lazy">`).join("")
    : `<div class="preview-placeholder">พื้นที่สำหรับภาพตัวอย่างชีท<br>เพิ่มไฟล์ภาพในโฟลเดอร์ previews แล้วใส่ชื่อไฟล์ใน script.js</div>`;
  dialogContent.innerHTML = `
    <p class="dialog-eyebrow">${escapeHtml(product.code || "STUDY MATERIAL")}</p>
    <h3>${escapeHtml(product.name)}</h3>
    <p class="dialog-description">${escapeHtml(product.description || "ยังไม่มีรายละเอียดสินค้า")}</p>
    <div class="dialog-prices">
      <div class="dialog-price"><small>MIDTERM</small><strong>${escapeHtml(formatPrice(product.midterm))}</strong></div>
      <div class="dialog-price"><small>FINAL</small><strong>${escapeHtml(formatPrice(product.final))}</strong></div>
      ${product.bundle !== "" ? `<div class="dialog-price"><small>MIDTERM + FINAL</small><strong>${escapeHtml(formatPrice(product.bundle))}</strong></div>` : ""}
    </div>
    <div class="preview-area"><h4>Preview</h4><div class="preview-gallery">${preview}</div></div>
    <a class="dialog-order" href="${STORE.lineUrl ? escapeHtml(STORE.lineUrl) : '#order'}" ${STORE.lineUrl ? 'target="_blank" rel="noopener"' : ''}>สอบถาม / สั่งซื้อผ่าน LINE ↗</a>
  `;
  dialog.showModal();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

document.getElementById("dialog-close").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});
document.getElementById("year").textContent = new Date().getFullYear();

const lineButton = document.getElementById("line-button");
const lineLabel = document.getElementById("line-id-label");
if (STORE.lineId) lineLabel.textContent = `LINE ID: ${STORE.lineId}`;
if (STORE.lineUrl) {
  lineButton.href = STORE.lineUrl;
  lineButton.target = "_blank";
  lineButton.rel = "noopener";
} else {
  lineButton.addEventListener("click", (event) => {
    event.preventDefault();
    alert("ยังไม่ได้ตั้งค่าลิงก์ LINE กรุณาใส่ LINE ID และลิงก์ในไฟล์ script.js ก่อนเผยแพร่");
  });
}
if (STORE.qrImage) {
  document.getElementById("qr-frame").innerHTML = `<img src="${escapeHtml(STORE.qrImage)}" alt="LINE QR Code" style="width:100%;height:100%;object-fit:contain;padding:10px">`;
}
renderProducts();
